# mathsquiz-app
A simple maths quiz app. ALC with google challenge.

This app is for learning purpose, therefore, it asks basic maths questions.
When you get a question right, it adds 2 to your overall score. 
It adds nothing when the answer is wrong.

At the end of the quiz, it displays your total score. It gives you encouragement 
if your score is not too good. It congratulates you if your score is good.

[Here is the link to the apk](https://drive.google.com/file/d/15Zan5BKm7ZRxnUZI-NxXcQE8I_fTHlEg/view?usp=sharing)


